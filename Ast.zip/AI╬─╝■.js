const fs = require('fs');
const { OpenAI } = require('openai');

const config = {
  base_url: "https://api.vectorengine.ai/v1",
  api_key: "自行购买处理",
  model: "gpt-5.2-chat",
  backupModel: "gpt-5.1-2025-11-13"
};

if (!config.api_key || config.api_key === "your_token_here") {
  console.error('❌ 请填写有效的 api_key');
  process.exit(1);
}

const openai = new OpenAI({
  apiKey: config.api_key,
  baseURL: config.base_url
});

const CODE_C = "./Code_B_path.js";
const CODE_D = "./Code_D_final.js";

async function deobfuscateCode() {
  try {
    let jsCode;
    try {
      jsCode = fs.readFileSync(CODE_C, { encoding: "utf-8" });
    } catch (err) {
      console.error(`❌ 读取文件失败：${err.message}`);
      console.error(`💡 检查文件路径是否正确：${CODE_C}`);
      return;
    }

    if (!jsCode || jsCode.trim() === "") {
      console.error('❌ 错误：待处理文件为空或仅含空白字符');
      return;
    }
    console.log(`📌 开始调用 ${config.model} 解混淆 [文件大小: ${(jsCode.length / 1024).toFixed(1)}KB]`);

    const completion = await openai.chat.completions.create({
      model: config.model,
      messages: [
        {
          role: 'system',
          content: `仅输出可运行的JS代码，无任何额外内容。处理规则：移除所有干扰性标识、还原加密字符串、重命名无意义变量、修复语法错误、删除无效分支，保证代码功能完整且可直接执行。`
        },
        {
          role: 'user',
          content: `处理以下JS代码，仅返回最终可运行的代码：\n${jsCode}`
        }
      ],
      temperature: 0,
      max_tokens: 8192,
      top_p: 1,
      timeout: 30000,
      user: 'deobfuscate_user'
    });

    const rawResult = completion?.choices?.[0]?.message?.content;
    if (!rawResult) {
      console.error('❌ AI返回空结果，可能是模型权限不足或请求参数错误');
      return;
    }

    const cleanCode = rawResult
      .replace(/^```(js|javascript)?\s*\n/, '')
      .replace(/```$/, '')
      .replace(/^\s*\/\/.*\n/g, '')
      .replace(/\n{3,}/g, '\n\n')
      .trim();

    try {
      fs.writeFileSync(CODE_D, cleanCode, { encoding: "utf-8" });
      console.log(`🎉 解混淆完成！`);
      console.log(`📤 输出文件：${CODE_D}`);
      console.log(`📊 最终代码大小：${(cleanCode.length / 1024).toFixed(1)}KB`);
    } catch (err) {
      console.error(`❌ 写入文件失败：${err.message}`);
      console.error(`💡 检查输出路径是否有权限：${CODE_D}`);
    }

  } catch (error) {
    console.error('\n❌ 解混淆核心错误：', error.message);
    if (error.response) {
      console.error('📌 平台返回状态码：', error.response.status);
      console.error('📌 平台错误详情：', JSON.stringify(error.response.data, null, 2));
    }
    if (error.message.includes('401')) {
      console.error('💡 错误原因：api_key无效或已过期，请在控制台刷新Key');
    } else if (error.message.includes('404')) {
      console.error(`💡 错误原因：模型 ${config.model} 不存在，请更换为 gpt-3.5-turbo / Qwen/Qwen2-7B-Instruct`);
    } else if (error.message.includes('503')) {
      console.error(`💡 错误原因：模型 ${config.model} 资源不足，请更换模型或稍后重试`);
    } else if (error.message.includes('timeout')) {
      console.error(`💡 错误原因：请求超时，建议减小文件大小或缩短超时时间`);
    }
  }
}

console.log('🚀 启动AI解混淆脚本...');
deobfuscateCode();