
const fs = require('fs');
const parser = require('@babel/parser');
const traverse = require('@babel/traverse').default;
const generator = require('@babel/generator').default;
const types = require('@babel/types');

const CONFIG = {
  inputPath: "./Code_A.js",
  outputPath: "./Code_B_path.js",
  whiteList: new Set([
    'window', 'document', 'String', 'Number', 'Array', 'Object',
    'decodeURIComponent', 'arguments', 'parseInt', 'Math',
    '_0xodX', 'version_'
  ]),
  confusePatterns: {
    varPrefix: ['_0x', 'tempVar_handle', 'inputData_handle'],
    funcNames: ['handleVal'],
    loopTest: {
      operator: '!',
      argumentType: 'ArrayExpression'
    },
    encryptComments: {
      v7: 'jsjiami.com.v7',
      v6: 'jsjiami.com.v6',
      safekodo: 'safekodo.com'
    }
  },
  semanticNames: {
    funcCore: ['encryptFunc', 'decodeFunc', 'mainFunc', 'dataHandleFunc', 'strProcessFunc'],
    param: ['inputData', 'keyStr', 'param1', 'param2', 'configObj', 'callbackFn'],
    index: ['loopIndex', 'charIndex', 'arrIndex', 'strIndex', 'stepIndex'],
    tempStr: ['tempStr', 'calcStr', 'resultStr', 'encodeStr', 'decodeStr'],
    tempNum: ['tempNum', 'calcNum', 'resultNum', 'encryptKey', 'decodeKey'],
    collection: ['dataArr', 'keyArr', 'resultArr', 'configObj', 'tempObj'],
    fallback: ['tempVar', 'tempVal', 'dataItem', 'processVal', 'handleVal']
  }
};

const createNameGenerator = () => {
  const nameIndexes = Object.fromEntries(
    Object.keys(CONFIG.semanticNames).map(key => [key, 0])
  );

  return {
    getUniqueName(type) {
      const names = CONFIG.semanticNames[type];
      const index = nameIndexes[type];
      if (index < names.length) {
        nameIndexes[type]++;
        return names[index];
      }
      nameIndexes[type]++;
      return `${names[0]}_${nameIndexes[type] - names.length}`;
    },
    getSemanticName(path) {
      const node = path.node;
      if (path.parent.type === 'FunctionDeclaration' && node === path.parent.id) {
        return this.getUniqueName('funcCore');
      }
      if ([ 'FunctionExpression', 'ArrowFunctionExpression' ].includes(path.parent.type) && 
          path.parent.params.includes(node)) {
        return this.getUniqueName('param');
      }
      if (path.parent.type === 'VariableDeclaration' && path.parent.parent?.type === 'ForStatement') {
        return this.getUniqueName('index');
      }
      if (path.parent.type === 'AssignmentExpression' && typeof path.parent.right?.value === 'string') {
        return this.getUniqueName('tempStr');
      }
      if (path.parent.type === 'AssignmentExpression' && typeof path.parent.right?.value === 'number') {
        return this.getUniqueName('tempNum');
      }
      if (path.parent.type === 'VariableDeclaration' && path.parent.init?.type === 'ArrayExpression') {
        return this.getUniqueName('collection');
      }
      return this.getUniqueName('fallback');
    }
  };
};

const collectAndReplaceConfuseVars = (ast, nameGenerator) => {
  const obfMap = new Map();

  traverse(ast, {
    Identifier(path) {
      const name = path.node.name;
      const isConfuseVar = CONFIG.confusePatterns.varPrefix.some(prefix => name.startsWith(prefix)) &&
                           !CONFIG.whiteList.has(name);
      
      if (isConfuseVar && !obfMap.has(name)) {
        obfMap.set(name, nameGenerator.getSemanticName(path));
      }
      if (name === 'version_' && !obfMap.has(name)) {
        obfMap.set(name, '小鱼混淆开发');
      }
    }
  });

  traverse(ast, {
    Identifier(path) {
      const name = path.node.name;
      if (obfMap.has(name)) {
        path.node.name = obfMap.get(name);
      }
    }
  });

  return obfMap;
};

const readFileStream = (path) => {
  return new Promise((resolve, reject) => {
    let content = '';
    const stream = fs.createReadStream(path, { encoding: 'utf-8' });
    stream.on('data', chunk => content += chunk);
    stream.on('end', () => resolve(content));
    stream.on('error', err => reject(err));
  });
};

const initAST = (code) => {
  return parser.parse(code, {
    sourceType: 'script',
    allowAwaitOutsideFunction: true,
    ranges: false,
    tokens: false,
    errorRecovery: true,
    plugins: ['optionalChaining', 'nullishCoalescingOperator'] 
  });
};

const extractEncryptInfo = (ast) => {
  const encryptInfo = {
    encryptFuncName: '',
    encryptArray: []
  };

  traverse(ast, {
    FunctionDeclaration(path) {
      const funcName = path.node.id?.name || '';
      const funcBody = JSON.stringify(path.node.body);

      if (funcBody.includes('processVal') && funcBody.includes('arguments')) {
        encryptInfo.encryptFuncName = funcName;
        console.log(`🔍 动态识别加密函数：${funcName}`);
      }

      if (funcName === CONFIG.confusePatterns.funcNames[0]) {
        const extractStrings = (node) => {
          if (types.isStringLiteral(node)) {
            encryptInfo.encryptArray.push(node.value);
          } else if (types.isArrayExpression(node)) {
            node.elements.forEach(elem => extractStrings(elem));
          } else if (types.isCallExpression(node)) {
            node.arguments.forEach(arg => extractStrings(arg));
            extractStrings(node.callee);
          } else if (types.isFunctionExpression(node)) {
            node.body.body.forEach(elem => extractStrings(elem));
          } else if (types.isReturnStatement(node)) {
            extractStrings(node.argument);
          } else if (types.isVariableDeclaration(node)) {
            node.declarations.forEach(decl => extractStrings(decl.init));
          }
        };
        extractStrings(path.node);
        console.log(`🔍 动态提取加密数组：共${encryptInfo.encryptArray.length}个值`);
      }
    }
  });

  return encryptInfo;
};

const cleanConfuseCode = (ast, encryptInfo) => {
  traverse(ast, {
    VariableDeclaration(path) {
      const commentValue = path.node.leadingComments?.[0]?.value?.replace(/\s+/g, ' ') || '';
      if (commentValue.includes(CONFIG.confusePatterns.encryptComments.safekodo)) {
        console.log('🔍 检测到：safekodo混淆');
      }
      if (commentValue.includes(CONFIG.confusePatterns.encryptComments.v6)) {
        console.log('🔍 检测到：v6混淆');
      }
      if (commentValue.includes(CONFIG.confusePatterns.encryptComments.v7)) {
        console.log('🔍 检测到：v7混淆，开始深度清理');
      }
    },

    CallExpression(path) {
      const callee = path.node.callee;
      if (types.isIdentifier(callee) && path.node.arguments.length === 2) {
        const [arg1, arg2] = path.node.arguments;
        const isHexNum = types.isNumericLiteral(arg1) && arg1.value.toString(16).startsWith('0x');
        const isStrArg = types.isStringLiteral(arg2);
        
        if (isHexNum && isStrArg) {
          const index = parseInt(arg1.value, 10);
          const realValue = encryptInfo.encryptArray[index] || '';
          if (realValue) {
            path.replaceWith(types.stringLiteral(realValue));
          }
        }
      }
    },

    FunctionDeclaration(path) {
      const funcName = path.node.id?.name || '';
      const funcBody = JSON.stringify(path.node.body);
      const isConfuseFunc = [funcName, encryptInfo.encryptFuncName].includes(funcName) ||
                            (funcBody.includes('!![]') && funcBody.includes('0x'));
      
      if (isConfuseFunc) {
        path.remove();
        console.log(`🚫 删除混淆函数：${funcName || '匿名函数'}`);
      }
    },

    WhileStatement(path) {
      const test = path.node.test;
      if (types.isUnaryExpression(test) && 
          test.operator === CONFIG.confusePatterns.loopTest.operator && 
          types.isArrayExpression(test.argument)) {
        path.remove();
        console.log(`🚫 删除死循环：while(!![])`);
      }
    },

    CallExpression: {
      exit(path) {
        const callee = path.node.callee;
        if (types.isFunctionExpression(callee)) {
          const funcBody = JSON.stringify(callee.body);
          if (funcBody.includes('0x') || funcBody.includes('!![]')) {
            path.remove();
            console.log(`🚫 删除自执行混淆函数`);
          }
        }
      }
    },

    UnaryExpression(path) {
      const expr = path.node;
      if (expr.operator === '!') {
        if (types.isArrayExpression(expr.argument)) {
          path.replaceWith(types.booleanLiteral(false));
        } else if (types.isUnaryExpression(expr.argument) && expr.argument.operator === '!') {
          path.replaceWith(types.booleanLiteral(true));
        }
      }
    },

    NumericLiteral(path) {
      const val = path.node.value;
      if (val > 0 && val.toString(16).length > 1) {
        path.node.value = parseInt(val, 10);
      }
    },

    ObjectProperty(path) {
      const key = path.node.key;
      if (types.isStringLiteral(key) && /^[a-zA-Z_]\w*$/.test(key.value)) {
        path.node.key = types.identifier(key.value);
      }
    }
  });
};

const generateCleanCode = (ast) => {
  let { code } = generator(ast, {
    indent: { style: '  ', size: 2 },
    compact: false,
    retainLines: false,
    jsescOption: { quotes: 'single' },
    comments: false
  });

  code = code
    .replace(/;;+/g, ';')
    .replace(/\n{2,}/g, '\n')
    .replace(/^\s*\n/g, '')
    .replace(/\s+/g, ' ')
    .trim();

  if (!code.includes(CONFIG.confusePatterns.encryptComments.v7)) {
    code += `\nvar 小鱼混淆开发 = '${CONFIG.confusePatterns.encryptComments.v7}';`;
  }

  return code;
};

const main = async () => {
  try {
    console.log('🚀 开始AST解混淆处理...');
    const jsCode = await readFileStream(CONFIG.inputPath);
    if (!jsCode.trim()) {
      throw new Error('输入文件为空或仅包含空白字符');
    }

    const ast = initAST(jsCode);
    const encryptInfo = extractEncryptInfo(ast);
    const nameGenerator = createNameGenerator();
    const obfMap = collectAndReplaceConfuseVars(ast, nameGenerator);
    console.log(`📊 共识别${obfMap.size}个混淆变量，已完成语义化替换`);

    cleanConfuseCode(ast, encryptInfo);
    const cleanCode = generateCleanCode(ast);

    await fs.promises.writeFile(CONFIG.outputPath, cleanCode, { encoding: 'utf-8' });
    
    const originalSize = (jsCode.length / 1024).toFixed(2);
    const cleanSize = (cleanCode.length / 1024).toFixed(2);
    const reduceRate = ((1 - cleanSize / originalSize) * 100).toFixed(2);
    
    console.log(`✅ 解混淆完成！`);
    console.log(`📥 原始文件大小：${originalSize} KB`);
    console.log(`📤 清理后文件大小：${cleanSize} KB`);
    console.log(`📉 体积减少：${reduceRate}%`);
    console.log(`📁 输出文件：${CONFIG.outputPath}`);

  } catch (error) {
    console.error('❌ 解混淆处理失败：', error.message);
    process.exit(1);
  }
};

main();